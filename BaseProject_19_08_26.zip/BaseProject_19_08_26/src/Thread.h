#ifndef __THREAD_H
#define __THREAD_H

int Init_Thread (void);

#endif /* __THREAD_H */
